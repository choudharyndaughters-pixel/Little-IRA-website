import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Instagram } from "lucide-react";

export default function HomePage() {
  return (
    <div className="bg-gradient-to-b from-green-100 to-yellow-50 text-gray-800 font-sans">
      {/* Hero Section */}
      <section className="text-center py-16 px-6">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl font-extrabold text-green-700 mb-4"
        >
          Little IRA by IRA Studio
        </motion.h1>
        <p className="text-xl text-yellow-700 font-medium mb-6">
          Handcrafted with Love 💚
        </p>
        <Button className="bg-green-600 hover:bg-green-700 text-white text-lg px-6 py-3 rounded-2xl shadow-md">
          Explore Our Collection
        </Button>
      </section>

      {/* About Section */}
      <section className="py-12 px-6 md:px-20 bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-green-700 mb-4">Our Story</h2>
          <p className="text-gray-700 leading-relaxed">
            Little IRA is a dream nurtured by two sisters, inspired by the joy of dressing little ones with love. Each dress is handcrafted, customized on order, and designed with a personal touch — because every baby deserves something unique.
          </p>
        </div>
      </section>

      {/* Catalogue Preview */}
      <section className="py-12 px-6 bg-yellow-50">
        <h2 className="text-3xl font-bold text-center text-green-700 mb-8">
          Featured Outfits
        </h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {[1, 2, 3].map((item) => (
            <Card key={item} className="rounded-2xl shadow-lg overflow-hidden">
              <CardContent className="p-0">
                <img
                  src={`https://placehold.co/400x500?text=Outfit+${item}`}
                  alt={`Outfit ${item}`}
                  className="w-full h-80 object-cover"
                />
                <div className="p-4 text-center">
                  <h3 className="font-semibold text-lg text-green-800 mb-2">
                    Handcrafted Dress {item}
                  </h3>
                  <Button variant="outline" className="text-green-700 border-green-700 hover:bg-green-100">
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Instagram Section */}
      <section className="py-12 text-center bg-green-100">
        <h2 className="text-3xl font-bold text-green-800 mb-4">Follow Us on Instagram</h2>
        <p className="text-gray-700 mb-6">See our latest creations and happy little customers!</p>
        <Button className="bg-pink-500 hover:bg-pink-600 text-white flex items-center gap-2 mx-auto">
          <Instagram className="w-5 h-5" /> @littleira
        </Button>
      </section>

      {/* Contact Section */}
      <footer className="bg-green-700 text-white text-center py-6">
        <p className="text-lg mb-2 font-medium">For Custom Orders</p>
        <p className="text-sm mb-1">Call or WhatsApp: <strong>9602345141</strong></p>
        <p className="text-sm">Or DM us on Instagram @littleira</p>
        <p className="mt-4 text-xs opacity-80">© 2025 Little IRA by IRA Studio</p>
      </footer>
    </div>
  );
}
