import { motion } from 'framer-motion';
import { Instagram } from 'lucide-react';

export default function HomePage() {
  return (
    <div style={{ background: 'linear-gradient(to bottom, #d1f7d1, #fff9d6)', color: '#333', fontFamily: 'sans-serif' }}>
      <section style={{ textAlign: 'center', padding: '4rem 1rem' }}>
        <motion.h1 initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}
          style={{ fontSize: '3rem', fontWeight: 'bold', color: '#2e7d32', marginBottom: '1rem' }}>
          Little IRA by IRA Studio
        </motion.h1>
        <p style={{ fontSize: '1.25rem', color: '#9e7e00', fontWeight: '500' }}>Handcrafted with Love 💚</p>
      </section>

      <section style={{ background: 'white', padding: '3rem 1rem', textAlign: 'center' }}>
        <h2 style={{ fontSize: '2rem', color: '#2e7d32', marginBottom: '1rem' }}>Our Story</h2>
        <p style={{ maxWidth: '600px', margin: '0 auto', color: '#555' }}>
          Little IRA is a dream nurtured by two sisters, inspired by the joy of dressing little ones with love. Each dress is handcrafted, customized on order, and designed with a personal touch — because every baby deserves something unique.
        </p>
      </section>

      <section style={{ background: '#fff9d6', padding: '3rem 1rem', textAlign: 'center' }}>
        <h2 style={{ fontSize: '2rem', color: '#2e7d32', marginBottom: '2rem' }}>Featured Outfits</h2>
        <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', flexWrap: 'wrap' }}>
          {[1,2,3].map((i) => (
            <div key={i} style={{ width: '250px', borderRadius: '20px', overflow: 'hidden', boxShadow: '0 4px 10px rgba(0,0,0,0.1)' }}>
              <img src={`https://placehold.co/300x400?text=Outfit+${i}`} alt={`Outfit ${i}`} style={{ width: '100%', height: 'auto' }} />
              <div style={{ padding: '1rem' }}>
                <h3 style={{ color: '#2e7d32', marginBottom: '0.5rem' }}>Handcrafted Dress {i}</h3>
                <button style={{ border: '1px solid #2e7d32', padding: '0.5rem 1rem', borderRadius: '8px', background: 'white', color: '#2e7d32', cursor: 'pointer' }}>View Details</button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section style={{ background: '#d1f7d1', padding: '3rem 1rem', textAlign: 'center' }}>
        <h2 style={{ fontSize: '2rem', color: '#2e7d32', marginBottom: '1rem' }}>Follow Us on Instagram</h2>
        <p style={{ color: '#555', marginBottom: '1rem' }}>See our latest creations and happy little customers!</p>
        <a href='https://instagram.com/littleira' target='_blank' rel='noreferrer' style={{ background: '#e91e63', color: 'white', padding: '0.75rem 1.5rem', borderRadius: '10px', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: '0.5rem' }}>
          <Instagram size={20}/> @littleira
        </a>
      </section>

      <footer style={{ background: '#2e7d32', color: 'white', textAlign: 'center', padding: '2rem 1rem' }}>
        <p style={{ fontSize: '1.1rem', marginBottom: '0.5rem' }}>For Custom Orders</p>
        <p style={{ margin: '0.25rem 0' }}>Call or WhatsApp: <strong>9602345141</strong></p>
        <p>Or DM us on Instagram @littleira</p>
        <p style={{ marginTop: '1rem', fontSize: '0.8rem', opacity: 0.8 }}>© 2025 Little IRA by IRA Studio</p>
      </footer>
    </div>
  );
}
